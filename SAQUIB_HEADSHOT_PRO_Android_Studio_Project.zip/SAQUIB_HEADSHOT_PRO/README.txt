SAQUIB HEADSHOT PRO — Android Studio project

This is a legitimate Free Fire MAX companion/training tracker. It does not modify
the game, automate gameplay, provide cheats, or access Garena accounts.

Build APK:
1. On a computer, install Android Studio.
2. Open this folder in Android Studio.
3. Let Gradle sync finish.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location when the build finishes.

Package name: com.saquib.headshotpro
Minimum Android version: Android 6.0 (API 23)

Note: This ZIP is the Android Studio project source, not a compiled APK.
